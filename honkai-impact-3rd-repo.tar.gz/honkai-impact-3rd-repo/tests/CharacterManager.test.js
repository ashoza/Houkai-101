import CharacterManager from '../src/characters/CharacterManager.js';

describe('CharacterManager', () => {
  let manager;

  beforeEach(() => {
    manager = new CharacterManager();
  });

  describe('Character Loading', () => {
    test('should load characters from JSON', () => {
      const chars = manager.getAllCharacters();
      expect(chars).toBeDefined();
      expect(Array.isArray(chars)).toBe(true);
      expect(chars.length).toBeGreaterThan(0);
    });
  });

  describe('Get Character', () => {
    test('should get character by ID', () => {
      const char = manager.getCharacter('herrscher-of-finality');
      expect(char).toBeDefined();
      expect(char.id).toBe('herrscher-of-finality');
      expect(char.name).toBe('Herrscher of Finality');
    });

    test('should get character by name', () => {
      const char = manager.getCharacter('Herrscher of Finality');
      expect(char).toBeDefined();
      expect(char.id).toBe('herrscher-of-finality');
    });

    test('should return null for non-existent character', () => {
      const char = manager.getCharacter('non-existent');
      expect(char).toBeNull();
    });
  });

  describe('Filter Characters', () => {
    test('should filter by element', () => {
      const fireChars = manager.getCharactersByElement('Fire');
      expect(fireChars.length).toBeGreaterThan(0);
      fireChars.forEach(char => {
        expect(char.element).toBe('Fire');
      });
    });

    test('should filter by type', () => {
      const mechChars = manager.getCharactersByType('Mech');
      expect(mechChars.length).toBeGreaterThan(0);
      mechChars.forEach(char => {
        expect(char.type).toBe('Mech');
      });
    });

    test('should filter by tier', () => {
      const sPlusChars = manager.getCharactersByTier('S+');
      expect(sPlusChars.length).toBeGreaterThan(0);
      sPlusChars.forEach(char => {
        expect(char.tierRating).toBe('S+');
      });
    });

    test('should filter by role', () => {
      const dpsChars = manager.getCharactersByRole('Main DPS');
      expect(dpsChars.length).toBeGreaterThan(0);
      dpsChars.forEach(char => {
        expect(char.role).toContain('DPS');
      });
    });
  });

  describe('Search Characters', () => {
    test('should search with single criterion', () => {
      const results = manager.searchCharacters({ element: 'Fire' });
      expect(results.length).toBeGreaterThan(0);
      results.forEach(char => {
        expect(char.element).toBe('Fire');
      });
    });

    test('should search with multiple criteria', () => {
      const results = manager.searchCharacters({
        element: 'Fire',
        type: 'Mech',
        tier: 'S+'
      });
      results.forEach(char => {
        expect(char.element).toBe('Fire');
        expect(char.type).toBe('Mech');
        expect(char.tierRating).toBe('S+');
      });
    });
  });

  describe('Character Equipment', () => {
    test('should get best stigmata for character', () => {
      const result = manager.getBestStigmata('Herrscher of Finality');
      expect(result).toBeDefined();
      expect(result.character).toBe('Herrscher of Finality');
      expect(result.bestStigmata).toBeDefined();
      expect(result.f2pAlternatives).toBeDefined();
    });

    test('should get best weapon for character', () => {
      const result = manager.getBestWeapon('Herrscher of Finality');
      expect(result).toBeDefined();
      expect(result.character).toBe('Herrscher of Finality');
      expect(result.bestWeapon).toBe('Key of Ego');
    });
  });

  describe('Character Comparison', () => {
    test('should compare multiple characters', () => {
      const comparison = manager.compareCharacters([
        'Herrscher of Finality',
        'Herrscher of Origin'
      ]);
      expect(comparison.characters).toBeDefined();
      expect(comparison.characters.length).toBe(2);
      expect(comparison.characters[0].name).toBeDefined();
      expect(comparison.characters[0].baseStats).toBeDefined();
    });

    test('should handle invalid character IDs', () => {
      const comparison = manager.compareCharacters([
        'invalid-id',
        'Herrscher of Finality'
      ]);
      expect(comparison.characters.length).toBe(1);
    });
  });

  describe('Power Score', () => {
    test('should calculate power score', () => {
      const score = manager.calculatePowerScore('Herrscher of Finality');
      expect(score).toBeGreaterThan(0);
      expect(typeof score).toBe('number');
    });

    test('should increase score with gear', () => {
      const baseScore = manager.calculatePowerScore('Herrscher of Finality');
      const gearScore = manager.calculatePowerScore('Herrscher of Finality', {
        hasSignatureWeapon: true,
        hasFullStigmataSet: true
      });
      expect(gearScore).toBeGreaterThan(baseScore);
    });
  });

  describe('Build Guide', () => {
    test('should get build guide', () => {
      const guide = manager.getBuildGuide('Herrscher of Finality');
      expect(guide).toBeDefined();
      expect(guide.character).toBe('Herrscher of Finality');
      expect(guide.optimalBuild).toBeDefined();
      expect(guide.f2pBuild).toBeDefined();
      expect(guide.skills).toBeDefined();
    });
  });

  describe('Team Suggestions', () => {
    test('should get team suggestions', () => {
      const suggestions = manager.getTeamSuggestions('Herrscher of Finality');
      expect(suggestions).toBeDefined();
      expect(suggestions.mainDPS).toBe('Herrscher of Finality');
      expect(suggestions.teammates).toBeDefined();
      expect(Array.isArray(suggestions.teammates)).toBe(true);
    });
  });
});
