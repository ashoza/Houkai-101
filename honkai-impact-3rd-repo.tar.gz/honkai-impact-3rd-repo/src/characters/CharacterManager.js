import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * CharacterManager - Manages character data and operations
 */
class CharacterManager {
  constructor() {
    this.characters = [];
    this.loadCharacters();
  }

  /**
   * Load character data from JSON file
   */
  loadCharacters() {
    try {
      const dataPath = path.join(__dirname, '../../data/characters/characters.json');
      const rawData = fs.readFileSync(dataPath, 'utf8');
      const data = JSON.parse(rawData);
      this.characters = data.characters;
      console.log(`Loaded ${this.characters.length} characters`);
    } catch (error) {
      console.error('Error loading characters:', error.message);
      this.characters = [];
    }
  }

  /**
   * Get all characters
   * @returns {Array} Array of all characters
   */
  getAllCharacters() {
    return this.characters;
  }

  /**
   * Get character by ID or name
   * @param {string} identifier - Character ID or name
   * @returns {Object|null} Character object or null if not found
   */
  getCharacter(identifier) {
    const lowerIdentifier = identifier.toLowerCase();
    return this.characters.find(char => 
      char.id === lowerIdentifier || 
      char.name.toLowerCase() === lowerIdentifier ||
      char.fullName.toLowerCase() === lowerIdentifier
    ) || null;
  }

  /**
   * Get characters by element
   * @param {string} element - Element type (Fire, Ice, Lightning, Physical)
   * @returns {Array} Array of characters with the specified element
   */
  getCharactersByElement(element) {
    return this.characters.filter(char => 
      char.element.toLowerCase() === element.toLowerCase()
    );
  }

  /**
   * Get characters by type
   * @param {string} type - Type (Mech, BIO, PSY, QUA, IMG)
   * @returns {Array} Array of characters with the specified type
   */
  getCharactersByType(type) {
    return this.characters.filter(char => 
      char.type.toLowerCase() === type.toLowerCase()
    );
  }

  /**
   * Get characters by tier rating
   * @param {string} tier - Tier rating (S+, S, A, etc.)
   * @returns {Array} Array of characters in the specified tier
   */
  getCharactersByTier(tier) {
    return this.characters.filter(char => 
      char.tierRating === tier
    );
  }

  /**
   * Get characters by role
   * @param {string} role - Role (Main DPS, Support, etc.)
   * @returns {Array} Array of characters with the specified role
   */
  getCharactersByRole(role) {
    return this.characters.filter(char => 
      char.role.toLowerCase().includes(role.toLowerCase())
    );
  }

  /**
   * Get best stigmata for a character
   * @param {string} characterId - Character ID or name
   * @returns {Object} Object containing best stigmata and alternatives
   */
  getBestStigmata(characterId) {
    const character = this.getCharacter(characterId);
    if (!character) {
      return { error: 'Character not found' };
    }

    return {
      character: character.name,
      bestStigmata: character.bestStigmata,
      f2pAlternatives: character.f2pAlternatives.stigmata
    };
  }

  /**
   * Get best weapon for a character
   * @param {string} characterId - Character ID or name
   * @returns {Object} Object containing best weapon and alternatives
   */
  getBestWeapon(characterId) {
    const character = this.getCharacter(characterId);
    if (!character) {
      return { error: 'Character not found' };
    }

    return {
      character: character.name,
      bestWeapon: character.bestWeapon,
      f2pAlternative: character.f2pAlternatives.weapon
    };
  }

  /**
   * Search characters by criteria
   * @param {Object} criteria - Search criteria object
   * @returns {Array} Array of matching characters
   */
  searchCharacters(criteria) {
    return this.characters.filter(char => {
      let matches = true;

      if (criteria.element) {
        matches = matches && char.element.toLowerCase() === criteria.element.toLowerCase();
      }
      if (criteria.type) {
        matches = matches && char.type.toLowerCase() === criteria.type.toLowerCase();
      }
      if (criteria.role) {
        matches = matches && char.role.toLowerCase().includes(criteria.role.toLowerCase());
      }
      if (criteria.tier) {
        matches = matches && char.tierRating === criteria.tier;
      }
      if (criteria.weapon) {
        matches = matches && char.weapon.toLowerCase() === criteria.weapon.toLowerCase();
      }

      return matches;
    });
  }

  /**
   * Get character stats comparison
   * @param {Array} characterIds - Array of character IDs to compare
   * @returns {Object} Comparison object
   */
  compareCharacters(characterIds) {
    const chars = characterIds.map(id => this.getCharacter(id)).filter(c => c !== null);
    
    if (chars.length === 0) {
      return { error: 'No valid characters found' };
    }

    return {
      characters: chars.map(char => ({
        name: char.name,
        element: char.element,
        type: char.type,
        tier: char.tierRating,
        baseStats: char.baseStats,
        pros: char.pros,
        cons: char.cons
      }))
    };
  }

  /**
   * Get meta team suggestions for a character
   * @param {string} characterId - Character ID or name
   * @returns {Object} Team suggestions
   */
  getTeamSuggestions(characterId) {
    const character = this.getCharacter(characterId);
    if (!character) {
      return { error: 'Character not found' };
    }

    // Find characters with matching elements for elemental teams
    const sameElement = this.getCharactersByElement(character.element)
      .filter(c => c.id !== character.id)
      .slice(0, 3);

    return {
      mainDPS: character.name,
      element: character.element,
      teammates: sameElement.map(c => ({
        name: c.name,
        role: c.role,
        synergy: 'Elemental resonance and team buffs'
      })),
      notes: `Build a team around ${character.element} damage with proper support characters.`
    };
  }

  /**
   * Calculate character power score (simplified)
   * @param {string} characterId - Character ID or name
   * @param {Object} gear - Gear configuration
   * @returns {number} Power score
   */
  calculatePowerScore(characterId, gear = {}) {
    const character = this.getCharacter(characterId);
    if (!character) {
      return 0;
    }

    let score = 1000; // Base score

    // Add stats
    score += character.baseStats.atk * 2;
    score += character.baseStats.hp * 0.1;
    score += character.baseStats.def * 0.5;
    score += character.baseStats.crt * 10;

    // Tier bonus
    const tierBonus = {
      'S+': 500,
      'S': 350,
      'A': 200,
      'B': 100
    };
    score += tierBonus[character.tierRating] || 0;

    // Gear bonus
    if (gear.hasSignatureWeapon) score += 300;
    if (gear.hasFullStigmataSet) score += 400;

    return Math.round(score);
  }

  /**
   * Get character build guide
   * @param {string} characterId - Character ID or name
   * @returns {Object} Build guide
   */
  getBuildGuide(characterId) {
    const character = this.getCharacter(characterId);
    if (!character) {
      return { error: 'Character not found' };
    }

    return {
      character: character.name,
      role: character.role,
      element: character.element,
      optimalBuild: {
        weapon: character.bestWeapon,
        stigmata: character.bestStigmata
      },
      f2pBuild: {
        weapon: character.f2pAlternatives.weapon,
        stigmata: character.f2pAlternatives.stigmata
      },
      playstyle: {
        pros: character.pros,
        cons: character.cons
      },
      skills: character.skills
    };
  }
}

export default CharacterManager;
