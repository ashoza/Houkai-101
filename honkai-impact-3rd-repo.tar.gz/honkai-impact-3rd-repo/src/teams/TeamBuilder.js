/**
 * TeamBuilder - Build and optimize team compositions for Honkai Impact 3rd
 */

class TeamBuilder {
  constructor(characterManager) {
    this.characterManager = characterManager;
    this.elementalSynergies = {
      'Fire': ['Fire', 'Lightning'],
      'Ice': ['Ice', 'Physical'],
      'Lightning': ['Lightning', 'Fire'],
      'Physical': ['Physical', 'Ice']
    };
    
    this.roleRequirements = {
      balanced: {
        'Main DPS': 1,
        'Support': 1,
        'Sub DPS': 1
      },
      aggressive: {
        'Main DPS': 2,
        'Support': 1
      },
      defensive: {
        'Main DPS': 1,
        'Support': 2
      }
    };
  }

  /**
   * Create a team composition
   * @param {Object} options - Team building options
   * @returns {Object} Team composition
   */
  buildTeam(options = {}) {
    const {
      mainDPS,
      preferredElement,
      strategy = 'balanced',
      availableCharacters = []
    } = options;

    if (!mainDPS) {
      return { error: 'Main DPS character is required' };
    }

    const dpsChar = this.characterManager.getCharacter(mainDPS);
    if (!dpsChar) {
      return { error: 'Main DPS character not found' };
    }

    const team = {
      mainDPS: dpsChar,
      members: [dpsChar],
      element: dpsChar.element,
      strategy: strategy
    };

    // Find support characters
    const supports = this._findBestSupports(dpsChar, availableCharacters, strategy);
    team.members.push(...supports);

    // Calculate team synergy
    team.synergy = this._calculateTeamSynergy(team.members);
    team.buffs = this._getTeamBuffs(team.members);
    team.coverage = this._getElementalCoverage(team.members);

    return team;
  }

  /**
   * Find best support characters for main DPS
   * @private
   */
  _findBestSupports(mainDPS, availableChars, strategy) {
    const allChars = availableChars.length > 0 
      ? availableChars.map(id => this.characterManager.getCharacter(id)).filter(c => c)
      : this.characterManager.getAllCharacters();

    // Filter out main DPS and get supports
    const potentialSupports = allChars.filter(char => 
      char.id !== mainDPS.id && char.role.toLowerCase().includes('support')
    );

    // Score each support
    const scored = potentialSupports.map(char => ({
      character: char,
      score: this._calculateSupportScore(char, mainDPS)
    }));

    // Sort by score and take top 2
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, 2).map(s => s.character);
  }

  /**
   * Calculate support score for a character
   * @private
   */
  _calculateSupportScore(support, mainDPS) {
    let score = 0;

    // Element matching
    if (support.element === mainDPS.element) {
      score += 50;
    } else if (this.elementalSynergies[mainDPS.element]?.includes(support.element)) {
      score += 25;
    }

    // Type diversity
    if (support.type !== mainDPS.type) {
      score += 20;
    }

    // Tier rating
    const tierScores = { 'S+': 40, 'S': 30, 'A': 20, 'B': 10 };
    score += tierScores[support.tierRating] || 0;

    return score;
  }

  /**
   * Calculate team synergy
   * @private
   */
  _calculateTeamSynergy(members) {
    let synergy = {
      elementalResonance: 0,
      typeCoverage: 0,
      roleBalance: 0,
      overall: 0
    };

    // Element resonance
    const elements = members.map(m => m.element);
    const uniqueElements = new Set(elements);
    
    if (uniqueElements.size === 1) {
      synergy.elementalResonance = 100; // Mono element team
    } else if (uniqueElements.size === 2) {
      synergy.elementalResonance = 60; // Dual element
    } else {
      synergy.elementalResonance = 30; // Mixed elements
    }

    // Type coverage
    const types = new Set(members.map(m => m.type));
    synergy.typeCoverage = (types.size / 5) * 100; // Max 5 types

    // Role balance
    const roles = members.map(m => m.role);
    const hasDPS = roles.some(r => r.toLowerCase().includes('dps'));
    const hasSupport = roles.some(r => r.toLowerCase().includes('support'));
    synergy.roleBalance = (hasDPS && hasSupport) ? 100 : 50;

    // Overall
    synergy.overall = Math.round(
      (synergy.elementalResonance * 0.4 + 
       synergy.typeCoverage * 0.3 + 
       synergy.roleBalance * 0.3)
    );

    return synergy;
  }

  /**
   * Get team buffs
   * @private
   */
  _getTeamBuffs(members) {
    const buffs = [];

    members.forEach(member => {
      if (member.skills?.leader) {
        buffs.push({
          source: member.name,
          type: 'Leader Skill',
          effect: member.skills.leader.description
        });
      }
    });

    return buffs;
  }

  /**
   * Get elemental coverage
   * @private
   */
  _getElementalCoverage(members) {
    const elements = members.map(m => m.element);
    return {
      elements: [...new Set(elements)],
      isMonoElement: new Set(elements).size === 1,
      mainElement: elements[0]
    };
  }

  /**
   * Suggest teams for specific content
   * @param {string} content - Content type (abyss, memorial, elysian)
   * @param {Array} availableCharacters - Available character IDs
   * @returns {Array} Suggested teams
   */
  suggestTeamsForContent(content, availableCharacters = []) {
    const contentStrategies = {
      abyss: {
        priorities: ['AOE', 'Elemental Coverage'],
        preferredRoles: ['Main DPS', 'Support']
      },
      memorial: {
        priorities: ['Single Target', 'Burst Damage'],
        preferredRoles: ['Main DPS', 'Buffer']
      },
      elysian: {
        priorities: ['Sustain', 'DPS'],
        preferredRoles: ['Main DPS', 'Support']
      }
    };

    const strategy = contentStrategies[content.toLowerCase()] || contentStrategies.abyss;
    const teams = [];

    // Get top tier characters
    const topChars = this.characterManager.getCharactersByTier('S+');
    
    topChars.slice(0, 3).forEach(mainDPS => {
      const team = this.buildTeam({
        mainDPS: mainDPS.id,
        strategy: 'balanced',
        availableCharacters: availableCharacters
      });
      
      if (!team.error) {
        team.contentType = content;
        team.recommendations = strategy.priorities;
        teams.push(team);
      }
    });

    return teams;
  }

  /**
   * Optimize team for specific boss
   * @param {string} bossName - Boss name
   * @param {Object} teamComposition - Current team
   * @returns {Object} Optimization suggestions
   */
  optimizeForBoss(bossName, teamComposition) {
    // Boss weaknesses database (simplified)
    const bossWeaknesses = {
      'Hephaestus': {
        element: 'Ice',
        type: 'BIO',
        resistances: ['Fire', 'Lightning']
      },
      'Dominator': {
        element: 'Fire',
        type: 'Mech',
        resistances: ['Ice', 'Physical']
      },
      'Jizo Mitama': {
        element: 'Lightning',
        type: 'PSY',
        resistances: ['Physical']
      }
    };

    const boss = bossWeaknesses[bossName];
    if (!boss) {
      return { suggestions: ['Boss data not available'] };
    }

    const suggestions = [];
    const team = teamComposition.members || [];

    // Check element matching
    const hasCounterElement = team.some(m => m.element === boss.element);
    if (!hasCounterElement) {
      suggestions.push({
        priority: 'high',
        suggestion: `Add ${boss.element} damage dealer to exploit boss weakness`
      });
    }

    // Check resistances
    const usesResisted = team.filter(m => boss.resistances.includes(m.element));
    if (usesResisted.length > 0) {
      suggestions.push({
        priority: 'medium',
        suggestion: `Replace ${usesResisted.map(c => c.name).join(', ')} - boss resists their element`
      });
    }

    // Check type advantage
    const typeAdvantage = this._getTypeAdvantage(boss.type);
    const hasTypeAdvantage = team.some(m => m.type === typeAdvantage);
    if (!hasTypeAdvantage) {
      suggestions.push({
        priority: 'low',
        suggestion: `Consider adding ${typeAdvantage} type for bonus damage`
      });
    }

    return {
      boss: bossName,
      weakness: boss,
      suggestions: suggestions
    };
  }

  /**
   * Get type advantage
   * @private
   */
  _getTypeAdvantage(type) {
    const advantages = {
      'Mech': 'PSY',
      'PSY': 'BIO',
      'BIO': 'Mech',
      'QUA': 'QUA',
      'IMG': 'IMG'
    };
    return advantages[type] || type;
  }

  /**
   * Calculate team power rating
   * @param {Array} teamMembers - Team member objects
   * @returns {number} Power rating
   */
  calculateTeamPower(teamMembers) {
    let totalPower = 0;

    teamMembers.forEach(member => {
      // Base power from tier
      const tierPower = {
        'S+': 1000,
        'S': 850,
        'A': 700,
        'B': 550
      };
      totalPower += tierPower[member.tierRating] || 500;

      // Bonus from stats
      totalPower += member.baseStats.atk * 2;
    });

    // Team synergy bonus
    const synergy = this._calculateTeamSynergy(teamMembers);
    totalPower += (synergy.overall / 100) * 300;

    return Math.round(totalPower);
  }

  /**
   * Get meta teams
   * @returns {Array} Current meta team compositions
   */
  getMetaTeams() {
    return [
      {
        name: 'Fire Supremacy',
        mainDPS: 'Herrscher of Finality',
        supports: ['Thelema: Mad King\'s Mask', 'Songque'],
        element: 'Fire',
        rating: 9.5,
        description: 'Dominant fire damage team with excellent synergy'
      },
      {
        name: 'Lightning Storm',
        mainDPS: 'Herrscher of Origin',
        supports: ['Herrscher of Truth', 'Senadina: Deepspace Anchor'],
        element: 'Lightning',
        rating: 9.3,
        description: 'High burst damage with chain lightning effects'
      },
      {
        name: 'Physical Dominance',
        mainDPS: 'Songque',
        supports: ['Herrscher of Finality', 'Herrscher of Truth'],
        element: 'Physical',
        rating: 9.0,
        description: 'Strong physical damage with good survivability'
      }
    ];
  }
}

export default TeamBuilder;
