import CharacterManager from './characters/CharacterManager.js';
import DamageCalculator from './damage-calculator/DamageCalculator.js';
import TeamBuilder from './teams/TeamBuilder.js';

/**
 * Main entry point for Honkai Impact 3rd Repository
 */

console.log('='.repeat(60));
console.log('Honkai Impact 3rd - Community Repository');
console.log('Version 1.0.0');
console.log('='.repeat(60));

// Initialize managers
const characterManager = new CharacterManager();
const damageCalculator = new DamageCalculator();
const teamBuilder = new TeamBuilder(characterManager);

console.log('\n📊 System initialized successfully!\n');

// Example 1: Get character information
console.log('Example 1: Character Information');
console.log('-'.repeat(60));
const hofi = characterManager.getCharacter('Herrscher of Finality');
if (hofi) {
  console.log(`Character: ${hofi.name}`);
  console.log(`Element: ${hofi.element}`);
  console.log(`Type: ${hofi.type}`);
  console.log(`Tier: ${hofi.tierRating}`);
  console.log(`Best Weapon: ${hofi.bestWeapon}`);
  console.log(`Best Stigmata: ${hofi.bestStigmata.join(', ')}`);
}

// Example 2: Calculate damage
console.log('\n\nExample 2: Damage Calculation');
console.log('-'.repeat(60));
const damageResult = damageCalculator.calculateBasicDamage({
  baseATK: 800,
  skillMultiplier: 250,
  totalDMG: 50,
  elementalDMG: 80,
  critRate: 60,
  critDMG: 150,
  enemyDEF: 400,
  enemyRES: 0
});
console.log(`Final Damage: ${damageResult.finalDamage.toLocaleString()}`);
console.log('Multipliers:', damageResult.multipliers);

// Example 3: Calculate DPS
console.log('\n\nExample 3: DPS Calculation');
console.log('-'.repeat(60));
const dpsResult = damageCalculator.calculateDPS({
  baseATK: 800,
  totalDMG: 50,
  elementalDMG: 80,
  critRate: 60,
  critDMG: 150,
  rotation: [
    { multiplier: 150, hits: 3 },
    { multiplier: 200, hits: 5 },
    { multiplier: 400, hits: 1 }
  ],
  duration: 20
});
console.log(`Total Damage: ${dpsResult.totalDamage.toLocaleString()}`);
console.log(`DPS: ${dpsResult.dps.toLocaleString()}`);
console.log(`Hit Count: ${dpsResult.hitCount}`);
console.log(`Average per Hit: ${dpsResult.avgDamagePerHit.toLocaleString()}`);

// Example 4: Build a team
console.log('\n\nExample 4: Team Building');
console.log('-'.repeat(60));
const team = teamBuilder.buildTeam({
  mainDPS: 'Herrscher of Finality',
  strategy: 'balanced'
});
if (!team.error) {
  console.log(`Main DPS: ${team.mainDPS.name}`);
  console.log('Team Members:');
  team.members.forEach((member, i) => {
    console.log(`  ${i + 1}. ${member.name} (${member.element} / ${member.type})`);
  });
  console.log(`\nTeam Synergy: ${team.synergy.overall}%`);
  console.log(`Element: ${team.coverage.mainElement}`);
  console.log(`Mono Element: ${team.coverage.isMonoElement ? 'Yes' : 'No'}`);
}

// Example 5: Get character by element
console.log('\n\nExample 5: Characters by Element');
console.log('-'.repeat(60));
const fireChars = characterManager.getCharactersByElement('Fire');
console.log(`Fire Characters (${fireChars.length}):`);
fireChars.forEach(char => {
  console.log(`  - ${char.name} (${char.tierRating})`);
});

// Example 6: Search characters
console.log('\n\nExample 6: Character Search');
console.log('-'.repeat(60));
const searchResults = characterManager.searchCharacters({
  element: 'Ice',
  tier: 'S'
});
console.log(`Ice S-Tier Characters (${searchResults.length}):`);
searchResults.forEach(char => {
  console.log(`  - ${char.name} (${char.role})`);
});

// Example 7: Get meta teams
console.log('\n\nExample 7: Meta Teams');
console.log('-'.repeat(60));
const metaTeams = teamBuilder.getMetaTeams();
metaTeams.forEach((team, i) => {
  console.log(`${i + 1}. ${team.name} (Rating: ${team.rating}/10)`);
  console.log(`   Main DPS: ${team.mainDPS}`);
  console.log(`   Supports: ${team.supports.join(', ')}`);
  console.log(`   ${team.description}`);
  console.log();
});

// Example 8: Compare characters
console.log('\nExample 8: Character Comparison');
console.log('-'.repeat(60));
const comparison = characterManager.compareCharacters([
  'Herrscher of Finality',
  'Herrscher of Origin',
  'Songque'
]);
if (!comparison.error) {
  console.log('Comparison:');
  comparison.characters.forEach(char => {
    console.log(`\n${char.name}:`);
    console.log(`  Element: ${char.element} | Type: ${char.type} | Tier: ${char.tier}`);
    console.log(`  ATK: ${char.baseStats.atk} | CRT: ${char.baseStats.crt}`);
  });
}

console.log('\n' + '='.repeat(60));
console.log('All examples completed!');
console.log('='.repeat(60));

// Export for use as module
export {
  characterManager,
  damageCalculator,
  teamBuilder
};
