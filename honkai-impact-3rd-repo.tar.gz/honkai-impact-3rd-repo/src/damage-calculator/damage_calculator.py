"""
Damage Calculator for Honkai Impact 3rd
Calculates damage output, DPS, and optimal builds
"""

import math
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CharacterStats:
    """Character base statistics"""
    hp: int
    atk: int
    defense: int
    crit_rate: float
    sp: int


@dataclass
class DamageParams:
    """Parameters for damage calculation"""
    base_atk: float
    skill_multiplier: float = 100.0
    total_dmg: float = 0.0
    elemental_dmg: float = 0.0
    crit_rate: float = 20.0
    crit_dmg: float = 50.0
    enemy_def: int = 400
    enemy_res: float = 0.0
    attacker_level: int = 80


class DamageCalculator:
    """
    Main damage calculator for Honkai Impact 3rd
    
    Damage Formula (simplified):
    Final Damage = Base ATK × Skill Multiplier × (1 + Total DMG%) × (1 + Elemental DMG%) 
                   × CRT Multiplier × DEF Multiplier × RES Multiplier
    """
    
    def __init__(self):
        self.default_params = DamageParams(base_atk=400)
    
    @staticmethod
    def crit_multiplier(crit_rate: float, crit_dmg: float) -> float:
        """Calculate critical hit multiplier"""
        return 1 + (crit_rate / 100) * (crit_dmg / 100)
    
    @staticmethod
    def def_multiplier(attacker_level: int, enemy_def: int) -> float:
        """Calculate defense multiplier"""
        return attacker_level / (attacker_level + enemy_def)
    
    @staticmethod
    def res_multiplier(elemental_res: float) -> float:
        """Calculate resistance multiplier"""
        return max(0, 1 - (elemental_res / 100))
    
    def calculate_basic_damage(self, params: DamageParams) -> Dict:
        """
        Calculate basic damage for a single hit
        
        Args:
            params: DamageParams object with calculation parameters
            
        Returns:
            Dictionary with damage breakdown
        """
        # Calculate multipliers
        crit_mult = self.crit_multiplier(params.crit_rate, params.crit_dmg)
        def_mult = self.def_multiplier(params.attacker_level, params.enemy_def)
        res_mult = self.res_multiplier(params.enemy_res)
        
        # Total damage modifiers
        total_dmg_mult = 1 + (params.total_dmg / 100)
        elemental_dmg_mult = 1 + (params.elemental_dmg / 100)
        
        # Calculate damage stages
        base_damage = params.base_atk * (params.skill_multiplier / 100)
        after_total = base_damage * total_dmg_mult
        after_elemental = after_total * elemental_dmg_mult
        after_crit = after_elemental * crit_mult
        after_def = after_crit * def_mult
        final_damage = after_def * res_mult
        
        return {
            'final_damage': round(final_damage),
            'breakdown': {
                'base_damage': round(base_damage),
                'after_total_dmg': round(after_total),
                'after_elemental_dmg': round(after_elemental),
                'after_crit': round(after_crit),
                'after_def': round(after_def),
                'final_damage': round(final_damage)
            },
            'multipliers': {
                'total': round(total_dmg_mult, 2),
                'elemental': round(elemental_dmg_mult, 2),
                'crit': round(crit_mult, 2),
                'def': round(def_mult, 2),
                'res': round(res_mult, 2)
            }
        }
    
    def calculate_dps(
        self,
        base_atk: float,
        rotation: List[Dict],
        duration: float = 20.0,
        **kwargs
    ) -> Dict:
        """
        Calculate DPS over a rotation
        
        Args:
            base_atk: Base attack value
            rotation: List of skills with multipliers and hits
            duration: Combat duration in seconds
            **kwargs: Additional damage parameters
            
        Returns:
            Dictionary with DPS results
        """
        total_damage = 0
        hit_count = 0
        
        # Create params object
        params = DamageParams(
            base_atk=base_atk,
            total_dmg=kwargs.get('total_dmg', 0),
            elemental_dmg=kwargs.get('elemental_dmg', 0),
            crit_rate=kwargs.get('crit_rate', 20),
            crit_dmg=kwargs.get('crit_dmg', 50),
            enemy_def=kwargs.get('enemy_def', 400),
            enemy_res=kwargs.get('enemy_res', 0)
        )
        
        # Calculate damage for each skill
        for skill in rotation:
            params.skill_multiplier = skill['multiplier']
            skill_damage = self.calculate_basic_damage(params)
            
            hits = skill.get('hits', 1)
            total_damage += skill_damage['final_damage'] * hits
            hit_count += hits
        
        dps = round(total_damage / duration)
        
        return {
            'total_damage': round(total_damage),
            'dps': dps,
            'duration': duration,
            'hit_count': hit_count,
            'avg_damage_per_hit': round(total_damage / hit_count) if hit_count > 0 else 0
        }
    
    def calculate_build_stats(
        self,
        character_stats: CharacterStats,
        weapon_atk: int = 0,
        weapon_crt: int = 0,
        stigmata_bonuses: Optional[Dict] = None
    ) -> Dict:
        """
        Calculate final stats for a build
        
        Args:
            character_stats: Character base stats
            weapon_atk: Weapon attack bonus
            weapon_crt: Weapon critical rate bonus
            stigmata_bonuses: Dictionary of stigmata bonuses
            
        Returns:
            Dictionary with final build stats
        """
        if stigmata_bonuses is None:
            stigmata_bonuses = {}
        
        final_atk = character_stats.atk + weapon_atk
        total_dmg = stigmata_bonuses.get('total_dmg', 0)
        elemental_dmg = stigmata_bonuses.get('elemental_dmg', 0)
        crit_rate = min(100, character_stats.crit_rate + weapon_crt + 
                       stigmata_bonuses.get('crit_rate', 0))
        crit_dmg = 50 + stigmata_bonuses.get('crit_dmg', 0)
        
        return {
            'final_atk': final_atk,
            'total_dmg': total_dmg,
            'elemental_dmg': elemental_dmg,
            'crit_rate': crit_rate,
            'crit_dmg': crit_dmg
        }
    
    def compare_builds(self, builds: List[Dict]) -> Dict:
        """
        Compare multiple builds
        
        Args:
            builds: List of build dictionaries with character and equipment
            
        Returns:
            Comparison results
        """
        results = []
        
        for i, build in enumerate(builds):
            stats = self.calculate_build_stats(
                build['character_stats'],
                build.get('weapon_atk', 0),
                build.get('weapon_crt', 0),
                build.get('stigmata_bonuses', {})
            )
            
            # Calculate DPS with simple rotation
            dps_result = self.calculate_dps(
                base_atk=stats['final_atk'],
                rotation=build.get('rotation', [{'multiplier': 100, 'hits': 1}]),
                total_dmg=stats['total_dmg'],
                elemental_dmg=stats['elemental_dmg'],
                crit_rate=stats['crit_rate'],
                crit_dmg=stats['crit_dmg']
            )
            
            results.append({
                'build_name': build.get('name', f'Build {i + 1}'),
                'stats': stats,
                'dps': dps_result['dps']
            })
        
        # Sort by DPS
        results.sort(key=lambda x: x['dps'], reverse=True)
        
        best_dps = results[0]['dps']
        
        return {
            'builds': results,
            'winner': results[0],
            'comparison': [
                {
                    'name': r['build_name'],
                    'dps': r['dps'],
                    'percent_of_best': f"{(r['dps'] / best_dps * 100):.1f}%"
                }
                for r in results
            ]
        }
    
    def optimize_stats(
        self,
        current_stats: Dict,
        stat_points: int = 100
    ) -> Dict:
        """
        Find optimal stat distribution
        
        Args:
            current_stats: Current stat values
            stat_points: Available points to distribute
            
        Returns:
            Optimized stat distribution
        """
        atk = current_stats.get('atk', 400)
        crit_rate = current_stats.get('crit_rate', 20)
        crit_dmg = current_stats.get('crit_dmg', 50)
        total_dmg = current_stats.get('total_dmg', 0)
        
        # Starting damage
        params = DamageParams(
            base_atk=atk,
            crit_rate=crit_rate,
            crit_dmg=crit_dmg,
            total_dmg=total_dmg
        )
        before_damage = self.calculate_basic_damage(params)['final_damage']
        
        # Simple greedy optimization
        for _ in range(stat_points):
            best_gain = 0
            best_stat = None
            
            # Try ATK
            test_params = DamageParams(
                base_atk=atk + 10,
                crit_rate=crit_rate,
                crit_dmg=crit_dmg,
                total_dmg=total_dmg
            )
            atk_damage = self.calculate_basic_damage(test_params)['final_damage']
            atk_gain = atk_damage - before_damage
            
            if atk_gain > best_gain:
                best_gain = atk_gain
                best_stat = 'atk'
            
            # Try Crit Rate (if not maxed)
            if crit_rate < 100:
                test_params = DamageParams(
                    base_atk=atk,
                    crit_rate=crit_rate + 1,
                    crit_dmg=crit_dmg,
                    total_dmg=total_dmg
                )
                cr_damage = self.calculate_basic_damage(test_params)['final_damage']
                cr_gain = cr_damage - before_damage
                
                if cr_gain > best_gain:
                    best_gain = cr_gain
                    best_stat = 'crit_rate'
            
            # Try Crit DMG
            test_params = DamageParams(
                base_atk=atk,
                crit_rate=crit_rate,
                crit_dmg=crit_dmg + 5,
                total_dmg=total_dmg
            )
            cd_damage = self.calculate_basic_damage(test_params)['final_damage']
            cd_gain = cd_damage - before_damage
            
            if cd_gain > best_gain:
                best_gain = cd_gain
                best_stat = 'crit_dmg'
            
            # Apply best improvement
            if best_stat == 'atk':
                atk += 10
            elif best_stat == 'crit_rate':
                crit_rate = min(100, crit_rate + 1)
            elif best_stat == 'crit_dmg':
                crit_dmg += 5
        
        # Calculate final damage
        params = DamageParams(
            base_atk=atk,
            crit_rate=crit_rate,
            crit_dmg=crit_dmg,
            total_dmg=total_dmg
        )
        after_damage = self.calculate_basic_damage(params)['final_damage']
        
        return {
            'optimized': {
                'atk': atk,
                'crit_rate': crit_rate,
                'crit_dmg': crit_dmg
            },
            'improvement': {
                'before': before_damage,
                'after': after_damage,
                'increase': after_damage - before_damage,
                'percent_increase': f"{((after_damage / before_damage - 1) * 100):.1f}%"
            }
        }


# Example usage
if __name__ == "__main__":
    calc = DamageCalculator()
    
    # Example: Calculate basic damage
    params = DamageParams(
        base_atk=800,
        skill_multiplier=250,
        total_dmg=50,
        elemental_dmg=80,
        crit_rate=60,
        crit_dmg=150
    )
    
    result = calc.calculate_basic_damage(params)
    print("Damage Calculation:")
    print(f"Final Damage: {result['final_damage']}")
    print(f"Breakdown: {result['breakdown']}")
    print(f"Multipliers: {result['multipliers']}")
