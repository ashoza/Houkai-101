/**
 * DamageCalculator - Calculate damage output for Honkai Impact 3rd characters
 * 
 * Damage formula (simplified):
 * Final Damage = Base ATK × Skill Multiplier × (1 + Total DMG%) × (1 + Elemental DMG%) 
 *                × CRT Multiplier × DEF Multiplier × RES Multiplier
 */

class DamageCalculator {
  constructor() {
    this.baseFormulas = {
      critMultiplier: (critRate, critDmg) => {
        return 1 + (critRate / 100) * (critDmg / 100);
      },
      defMultiplier: (attackerLevel, enemyDef) => {
        const level = attackerLevel || 80;
        return level / (level + enemyDef);
      },
      resMultiplier: (elementalRes) => {
        return Math.max(0, 1 - (elementalRes / 100));
      }
    };
  }

  /**
   * Calculate basic damage for a single hit
   * @param {Object} params - Damage calculation parameters
   * @returns {Object} Damage breakdown
   */
  calculateBasicDamage(params) {
    const {
      baseATK = 400,
      skillMultiplier = 100,
      totalDMG = 0,
      elementalDMG = 0,
      critRate = 20,
      critDMG = 50,
      enemyDEF = 400,
      enemyRES = 0,
      attackerLevel = 80
    } = params;

    // Calculate multipliers
    const critMultiplier = this.baseFormulas.critMultiplier(critRate, critDMG);
    const defMultiplier = this.baseFormulas.defMultiplier(attackerLevel, enemyDEF);
    const resMultiplier = this.baseFormulas.resMultiplier(enemyRES);

    // Total damage modifiers
    const totalDmgMultiplier = 1 + (totalDMG / 100);
    const elementalDmgMultiplier = 1 + (elementalDMG / 100);

    // Calculate final damage
    const baseDamage = baseATK * (skillMultiplier / 100);
    const damageWithModifiers = baseDamage * totalDmgMultiplier * elementalDmgMultiplier;
    const finalDamage = damageWithModifiers * critMultiplier * defMultiplier * resMultiplier;

    return {
      finalDamage: Math.round(finalDamage),
      breakdown: {
        baseDamage: Math.round(baseDamage),
        afterTotalDMG: Math.round(baseDamage * totalDmgMultiplier),
        afterElementalDMG: Math.round(damageWithModifiers),
        afterCrit: Math.round(damageWithModifiers * critMultiplier),
        afterDEF: Math.round(damageWithModifiers * critMultiplier * defMultiplier),
        finalDamage: Math.round(finalDamage)
      },
      multipliers: {
        total: totalDmgMultiplier.toFixed(2),
        elemental: elementalDmgMultiplier.toFixed(2),
        crit: critMultiplier.toFixed(2),
        def: defMultiplier.toFixed(2),
        res: resMultiplier.toFixed(2)
      }
    };
  }

  /**
   * Calculate DPS over a rotation
   * @param {Object} params - DPS calculation parameters
   * @returns {Object} DPS result
   */
  calculateDPS(params) {
    const {
      baseATK = 400,
      rotation = [],
      duration = 20,
      critRate = 20,
      critDMG = 50,
      totalDMG = 0,
      elementalDMG = 0,
      enemyDEF = 400,
      enemyRES = 0
    } = params;

    let totalDamage = 0;
    let hitCount = 0;

    // Calculate damage for each skill in rotation
    for (const skill of rotation) {
      const skillDamage = this.calculateBasicDamage({
        baseATK,
        skillMultiplier: skill.multiplier,
        totalDMG,
        elementalDMG,
        critRate,
        critDMG,
        enemyDEF,
        enemyRES
      });

      const hits = skill.hits || 1;
      totalDamage += skillDamage.finalDamage * hits;
      hitCount += hits;
    }

    const dps = Math.round(totalDamage / duration);

    return {
      totalDamage: Math.round(totalDamage),
      dps: dps,
      duration: duration,
      hitCount: hitCount,
      avgDamagePerHit: Math.round(totalDamage / hitCount)
    };
  }

  /**
   * Calculate optimal build stats
   * @param {Object} character - Character data
   * @param {Object} equipment - Equipment data
   * @returns {Object} Build stats
   */
  calculateBuildStats(character, equipment) {
    const baseATK = character.baseStats.atk + (equipment.weapon?.atk || 0);
    const baseCRT = character.baseStats.crt + (equipment.weapon?.crt || 0);

    let totalDMG = 0;
    let elementalDMG = 0;
    let critRate = baseCRT;
    let critDMG = 50; // Base CRT DMG

    // Add stigmata bonuses
    if (equipment.stigmata) {
      for (const stig of equipment.stigmata) {
        if (stig.effects) {
          totalDMG += stig.effects.totalDMG || 0;
          elementalDMG += stig.effects.elementalDMG || 0;
          critRate += stig.effects.critRate || 0;
          critDMG += stig.effects.critDMG || 0;
        }
      }
    }

    // Add weapon passive bonuses
    if (equipment.weapon?.passive) {
      totalDMG += equipment.weapon.passive.totalDMG || 0;
      elementalDMG += equipment.weapon.passive.elementalDMG || 0;
    }

    return {
      finalATK: Math.round(baseATK),
      totalDMG: totalDMG,
      elementalDMG: elementalDMG,
      critRate: Math.min(100, critRate),
      critDMG: critDMG,
      effectiveDPS: this.calculateDPS({
        baseATK,
        totalDMG,
        elementalDMG,
        critRate,
        critDMG,
        rotation: character.rotation || []
      })
    };
  }

  /**
   * Compare builds
   * @param {Array} builds - Array of build configurations
   * @returns {Object} Comparison results
   */
  compareBuilds(builds) {
    const results = builds.map((build, index) => {
      const stats = this.calculateBuildStats(build.character, build.equipment);
      return {
        buildName: build.name || `Build ${index + 1}`,
        stats: stats,
        dps: stats.effectiveDPS.dps
      };
    });

    // Sort by DPS
    results.sort((a, b) => b.dps - a.dps);

    return {
      builds: results,
      winner: results[0],
      comparison: results.map(r => ({
        name: r.buildName,
        dps: r.dps,
        percentOfBest: ((r.dps / results[0].dps) * 100).toFixed(1) + '%'
      }))
    };
  }

  /**
   * Calculate team total damage
   * @param {Array} team - Array of team members with their builds
   * @param {number} duration - Combat duration in seconds
   * @returns {Object} Team damage results
   */
  calculateTeamDamage(team, duration = 20) {
    let totalTeamDamage = 0;
    const memberResults = [];

    for (const member of team) {
      const stats = this.calculateBuildStats(member.character, member.equipment);
      const memberDamage = stats.effectiveDPS.dps * duration;
      
      totalTeamDamage += memberDamage;
      memberResults.push({
        name: member.character.name,
        damage: memberDamage,
        dps: stats.effectiveDPS.dps
      });
    }

    return {
      totalDamage: Math.round(totalTeamDamage),
      totalDPS: Math.round(totalTeamDamage / duration),
      duration: duration,
      members: memberResults.map(m => ({
        ...m,
        contribution: ((m.damage / totalTeamDamage) * 100).toFixed(1) + '%'
      }))
    };
  }

  /**
   * Calculate optimal stat distribution
   * @param {number} statPoints - Available stat points
   * @param {Object} currentStats - Current stat values
   * @returns {Object} Optimal distribution
   */
  optimizeStats(statPoints, currentStats) {
    const { atk, critRate, critDMG, totalDMG } = currentStats;
    
    // Simplified optimization: balance between ATK and CRT
    const atkValue = atk / 10; // Each 10 ATK = 1 value point
    const critValue = critRate * critDMG / 1000; // Combined crit value
    
    let optimalATK = atk;
    let optimalCritRate = critRate;
    let optimalCritDMG = critDMG;
    
    // Distribute points (simplified algorithm)
    let remainingPoints = statPoints;
    
    while (remainingPoints > 0) {
      const currentValue = this.calculateBasicDamage({
        baseATK: optimalATK,
        critRate: optimalCritRate,
        critDMG: optimalCritDMG,
        totalDMG: totalDMG
      }).finalDamage;
      
      // Try adding to each stat
      const atkOption = this.calculateBasicDamage({
        baseATK: optimalATK + 10,
        critRate: optimalCritRate,
        critDMG: optimalCritDMG,
        totalDMG: totalDMG
      }).finalDamage;
      
      const critRateOption = this.calculateBasicDamage({
        baseATK: optimalATK,
        critRate: Math.min(100, optimalCritRate + 1),
        critDMG: optimalCritDMG,
        totalDMG: totalDMG
      }).finalDamage;
      
      const critDMGOption = this.calculateBasicDamage({
        baseATK: optimalATK,
        critRate: optimalCritRate,
        critDMG: optimalCritDMG + 5,
        totalDMG: totalDMG
      }).finalDamage;
      
      // Choose best improvement
      const improvements = [
        { stat: 'atk', value: atkOption - currentValue },
        { stat: 'critRate', value: critRateOption - currentValue },
        { stat: 'critDMG', value: critDMGOption - currentValue }
      ];
      
      const best = improvements.sort((a, b) => b.value - a.value)[0];
      
      if (best.stat === 'atk') optimalATK += 10;
      else if (best.stat === 'critRate' && optimalCritRate < 100) optimalCritRate += 1;
      else optimalCritDMG += 5;
      
      remainingPoints--;
    }
    
    return {
      optimized: {
        atk: optimalATK,
        critRate: optimalCritRate,
        critDMG: optimalCritDMG
      },
      improvement: {
        before: this.calculateBasicDamage({
          baseATK: atk,
          critRate: critRate,
          critDMG: critDMG,
          totalDMG: totalDMG
        }).finalDamage,
        after: this.calculateBasicDamage({
          baseATK: optimalATK,
          critRate: optimalCritRate,
          critDMG: optimalCritDMG,
          totalDMG: totalDMG
        }).finalDamage
      }
    };
  }
}

export default DamageCalculator;
