# Team Building Guide

A comprehensive guide to building effective teams in Honkai Impact 3rd.

## 🎯 Team Composition Basics

### Standard Team Structure

A typical team consists of 3 characters:
1. **Main DPS** - Primary damage dealer
2. **Support** - Buffs, debuffs, and utility
3. **Sub-DPS/Support** - Additional damage or support

## 🌈 Elemental Teams

### Fire Teams

**Core Strategy**: Stack fire damage bonuses and burn effects

**Example Teams**:
- Herrscher of Finality + Thelema + Fire Support
- Focus: Continuous fire damage and ignite application

**Key Mechanics**:
- Elemental resonance bonus
- Burn status application
- Fire resistance reduction

### Ice Teams

**Core Strategy**: Freeze enemies and maximize ice damage

**Example Teams**:
- Herrscher of Truth + Senadina + Ice Support
- Focus: Crowd control and ice field management

**Key Mechanics**:
- Freeze duration extension
- Ice resistance reduction
- Construct synergies

### Lightning Teams

**Core Strategy**: Chain lightning and paralysis

**Example Teams**:
- Herrscher of Origin + Lightning Support x2
- Focus: Chain lightning procs and rapid hits

**Key Mechanics**:
- Chain lightning triggers
- Paralysis application
- Lightning mark exploitation

### Physical Teams

**Core Strategy**: Defense reduction and raw damage

**Example Teams**:
- Songque + Physical Support x2
- Focus: Breaking shields and sustained damage

**Key Mechanics**:
- Physical resistance reduction
- Shield breaking
- Combo maintenance

## 🎭 Role Synergies

### DPS + Support

**Optimal Pairing**:
- Support provides elemental buffs matching DPS element
- Support applies resistance reduction
- Support generates SP for DPS

**Example**: 
```
Herrscher of Finality (Fire DPS)
+ Support with Fire DMG buffs
+ Support with RES reduction
```

### Mono-Element Teams

**Advantages**:
- Maximum elemental damage bonus
- Strong against elemental-weak enemies
- Simplified buff management

**Disadvantages**:
- Weak against resistant enemies
- Less flexible

### Dual-Element Teams

**Advantages**:
- More flexibility
- Better enemy coverage
- Can exploit multiple weaknesses

**Disadvantages**:
- Diluted elemental buffs
- More complex rotations

## 🎪 Content-Specific Teams

### Memorial Arena

**Requirements**:
- High single-target burst damage
- Elemental coverage for boss weaknesses
- Time-limited optimization

**Team Building Tips**:
1. Check boss elemental weakness
2. Build mono-element counter team
3. Focus on burst damage rotations
4. Time ultimate usage carefully

**Example Setup**:
```
Boss: Weak to Ice
Team: HoTr + Ana + Ice Support
Strategy: Freeze → Ultimate → Burst combo
```

### Abyss (Superstring Dimension)

**Requirements**:
- AOE damage for mob clearing
- Elemental coverage for shields
- Sustained damage over time

**Team Building Tips**:
1. Prioritize AOE abilities
2. Bring multiple elements
3. Include crowd control
4. Maintain buff uptime

### Elysian Realm

**Requirements**:
- Synergy with signets
- Self-sustaining capabilities
- Adaptable to different bonus types

**Team Building Tips**:
1. Choose DPS with good signet synergy
2. Support should enable main DPS
3. Consider healing/sustain options
4. Plan for long runs

## 🔄 Team Rotations

### Basic Rotation Structure

```
1. Switch to Support 1
   - Apply buffs/debuffs
   - Generate SP if possible

2. Switch to Support 2
   - Apply additional buffs
   - Time fracture if available

3. Switch to Main DPS
   - Activate burst mode
   - Use ultimate
   - Deal maximum damage

4. Repeat cycle
```

### Advanced Rotation Tips

- **QTE Chains**: Link character switches with QTEs
- **Time Fracture**: Maximize damage during slow-mo
- **Ultimate Timing**: Sync ultimates with buff windows
- **SP Management**: Ensure DPS has enough SP for rotation

## 📊 Team Synergy Factors

### High Synergy Indicators

✅ Matching elements
✅ Complementary roles
✅ Buff alignment
✅ QTE chains
✅ Shared equipment bonuses

### Low Synergy Indicators

❌ Conflicting elements
❌ Overlapping roles
❌ Buff/debuff overwriting
❌ No QTE connections
❌ Wasted passive effects

## 🎯 F2P Team Building

### Budget Team Example 1: Physical

```
Main DPS: A-rank Physical character
Support 1: Starlit Astrologos (farmable)
Support 2: Drive Kometa (farmable)

Cost: Minimal gacha required
Effectiveness: Good for early-mid game
```

### Budget Team Example 2: Elemental

```
Main DPS: Event S-rank (free)
Support 1: Fischl (free from event)
Support 2: Farmable support

Cost: No gacha
Effectiveness: Solid for most content
```

### Upgrade Priority

1. Get Main DPS to SSS rank
2. Obtain signature weapon for DPS
3. Complete stigmata set for DPS
4. Upgrade support characters
5. Optimize support gear

## 🌟 Meta Teams (v7.9)

### Top Tier Teams

**1. Fire Supremacy**
- HoFinality + Thelema + Fire Support
- Rating: 9.5/10
- Best For: All content
- Investment: High

**2. Lightning Storm**
- HoOrigin + Lightning Support x2
- Rating: 9.3/10
- Best For: Memorial Arena, Abyss
- Investment: High

**3. Ice Fortress**
- HoTruth + Senadina + Ice Support
- Rating: 9.0/10
- Best For: Abyss, ER
- Investment: Medium-High

**4. Physical Dominance**
- Songque + Physical Support x2
- Rating: 9.0/10
- Best For: Memorial Arena
- Investment: Medium

## 🛠️ Team Building Tools

### Using the Team Builder

```javascript
import TeamBuilder from './src/teams/TeamBuilder.js';
import CharacterManager from './src/characters/CharacterManager.js';

const charManager = new CharacterManager();
const teamBuilder = new TeamBuilder(charManager);

// Build a team
const team = teamBuilder.buildTeam({
  mainDPS: 'Herrscher of Finality',
  strategy: 'balanced'
});

console.log(team);
```

### Optimization Functions

```javascript
// Optimize for specific boss
const optimization = teamBuilder.optimizeForBoss(
  'Hephaestus',
  currentTeam
);

// Get content-specific teams
const abyssTeams = teamBuilder.suggestTeamsForContent(
  'abyss',
  availableCharacters
);
```

## 💡 Advanced Tips

### 1. Type Advantage
- Mech > PSY > BIO > Mech
- QUA counters QUA
- IMG counters IMG

### 2. Leader Skills
Choose leader based on:
- Team element
- DPS requirements
- Specific content needs

### 3. Equipment Sharing
Plan equipment sets for:
- Multiple team compositions
- Same-element characters
- Content-specific needs

### 4. Buff Stacking
Understand which buffs:
- Stack additively
- Stack multiplicatively
- Overwrite each other

## 📈 Team Power Calculation

```javascript
// Calculate team power
const power = teamBuilder.calculateTeamPower([
  character1,
  character2,
  character3
]);

console.log(`Team Power: ${power}`);
```

## 🎓 Learning Resources

- Watch high-level gameplay
- Study rotation guides
- Join community Discord
- Check tier lists regularly
- Experiment in low-stakes content

## 📝 Checklist for Team Building

- [ ] Main DPS selected
- [ ] Elements synergize
- [ ] Roles complementary
- [ ] Equipment optimized
- [ ] Rotation planned
- [ ] QTE chains mapped
- [ ] Tested in practice
- [ ] Adjusted for content

---

Remember: The best team is the one you enjoy playing and fits your playstyle! Don't be afraid to experiment and find what works for you.
