# Contributing to Honkai Impact 3rd Repository

Thank you for your interest in contributing! This document provides guidelines for contributing to the project.

## 🌟 How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear description of the bug
- Steps to reproduce
- Expected vs actual behavior
- Screenshots if applicable
- Your environment (OS, Node/Python version)

### Suggesting Features

We welcome feature suggestions! Please:
- Check if the feature is already requested
- Clearly describe the feature and its benefits
- Provide examples of how it would be used

### Submitting Pull Requests

1. **Fork the Repository**
   ```bash
   git clone https://github.com/yourusername/honkai-impact-3rd-repo.git
   cd honkai-impact-3rd-repo
   ```

2. **Create a Feature Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make Your Changes**
   - Follow the code style guidelines
   - Add tests for new features
   - Update documentation as needed

4. **Test Your Changes**
   ```bash
   # JavaScript
   npm test
   
   # Python
   pytest tests/
   ```

5. **Commit Your Changes**
   ```bash
   git add .
   git commit -m "feat: add new feature description"
   ```

   Follow conventional commits:
   - `feat:` new feature
   - `fix:` bug fix
   - `docs:` documentation changes
   - `test:` adding tests
   - `refactor:` code refactoring

6. **Push and Create PR**
   ```bash
   git push origin feature/your-feature-name
   ```
   Then create a pull request on GitHub.

## 📝 Code Style Guidelines

### JavaScript
- Use ES6+ features
- Use meaningful variable names
- Add JSDoc comments for functions
- Follow the existing code structure
- Use 2 spaces for indentation

Example:
```javascript
/**
 * Calculate damage for a character
 * @param {Object} params - Damage parameters
 * @returns {number} Final damage value
 */
function calculateDamage(params) {
  // Implementation
}
```

### Python
- Follow PEP 8 style guide
- Use type hints
- Add docstrings for functions
- Use 4 spaces for indentation

Example:
```python
def calculate_damage(base_atk: float, multiplier: float) -> float:
    """
    Calculate damage output.
    
    Args:
        base_atk: Base attack value
        multiplier: Skill multiplier
        
    Returns:
        Final damage value
    """
    return base_atk * multiplier
```

## 🗂️ Project Structure

- `src/` - Source code
  - `characters/` - Character management
  - `weapons/` - Weapon systems
  - `stigmata/` - Stigmata data
  - `teams/` - Team building
  - `damage-calculator/` - DPS calculations
- `data/` - Game data (JSON)
- `tests/` - Unit tests
- `docs/` - Documentation

## 📊 Data Guidelines

When adding or updating game data:

### Character Data
- Include all required fields
- Verify stats against official sources
- Update both JS and Python versions
- Add tests for new characters

### Weapons/Stigmata
- Include complete passive descriptions
- Add obtain methods
- Specify best character matches
- Update related character data

## 🧪 Testing

All new features should include tests:

```javascript
// JavaScript test example
describe('New Feature', () => {
  test('should do something', () => {
    const result = newFeature();
    expect(result).toBe(expectedValue);
  });
});
```

```python
# Python test example
def test_new_feature():
    result = new_feature()
    assert result == expected_value
```

## 📚 Documentation

- Update README.md if adding major features
- Add JSDoc/docstrings for all functions
- Create examples in `/docs` for complex features
- Update changelog

## 🎯 Priority Areas

We especially welcome contributions in:
- [ ] Additional character data
- [ ] Elysian Realm signets database
- [ ] Memorial Arena boss guides
- [ ] Team composition algorithms
- [ ] Damage calculation improvements
- [ ] UI/UX improvements
- [ ] Test coverage
- [ ] Documentation

## ⚖️ Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Focus on what is best for the community
- Show empathy towards others

## 📧 Questions?

- Open an issue for questions
- Join our Discord community
- Check existing issues and PRs

## 🙏 Attribution

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Project documentation

Thank you for contributing to the Honkai Impact 3rd community! 🎮✨
