#!/usr/bin/env python3
"""
Example usage script for Honkai Impact 3rd Repository (Python version)
Demonstrates the damage calculator and character analysis
"""

import sys
import json
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from damage_calculator.damage_calculator import (
    DamageCalculator,
    DamageParams,
    CharacterStats
)


def print_header(title):
    """Print a formatted header"""
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


def load_character_data():
    """Load character data from JSON"""
    data_path = Path(__file__).parent / 'data' / 'characters' / 'characters.json'
    with open(data_path, 'r') as f:
        return json.load(f)


def example_basic_damage():
    """Example 1: Basic damage calculation"""
    print_header("Example 1: Basic Damage Calculation")
    
    calc = DamageCalculator()
    
    params = DamageParams(
        base_atk=800,
        skill_multiplier=250,
        total_dmg=50,
        elemental_dmg=80,
        crit_rate=60,
        crit_dmg=150,
        enemy_def=400,
        enemy_res=0
    )
    
    result = calc.calculate_basic_damage(params)
    
    print(f"\nFinal Damage: {result['final_damage']:,}")
    print("\nDamage Breakdown:")
    for stage, value in result['breakdown'].items():
        print(f"  {stage.replace('_', ' ').title()}: {value:,}")
    
    print("\nMultipliers:")
    for mult_type, value in result['multipliers'].items():
        print(f"  {mult_type.title()}: {value}")


def example_dps_calculation():
    """Example 2: DPS calculation"""
    print_header("Example 2: DPS Calculation")
    
    calc = DamageCalculator()
    
    rotation = [
        {'multiplier': 150, 'hits': 3},
        {'multiplier': 200, 'hits': 5},
        {'multiplier': 400, 'hits': 1}
    ]
    
    result = calc.calculate_dps(
        base_atk=800,
        rotation=rotation,
        duration=20,
        total_dmg=50,
        elemental_dmg=80,
        crit_rate=60,
        crit_dmg=150
    )
    
    print(f"\nTotal Damage: {result['total_damage']:,}")
    print(f"DPS: {result['dps']:,}")
    print(f"Duration: {result['duration']}s")
    print(f"Hit Count: {result['hit_count']}")
    print(f"Average per Hit: {result['avg_damage_per_hit']:,}")


def example_build_comparison():
    """Example 3: Build comparison"""
    print_header("Example 3: Build Comparison")
    
    calc = DamageCalculator()
    
    char_stats = CharacterStats(
        hp=1382,
        atk=427,
        defense=178,
        crit_rate=18,
        sp=200
    )
    
    # Define builds
    builds = [
        {
            'name': 'Optimal Build (Signature Gear)',
            'character_stats': char_stats,
            'weapon_atk': 325,
            'weapon_crt': 28,
            'stigmata_bonuses': {
                'total_dmg': 50,
                'elemental_dmg': 80,
                'crit_rate': 20,
                'crit_dmg': 100
            },
            'rotation': [
                {'multiplier': 150, 'hits': 3},
                {'multiplier': 250, 'hits': 1}
            ]
        },
        {
            'name': 'F2P Build',
            'character_stats': char_stats,
            'weapon_atk': 265,
            'weapon_crt': 18,
            'stigmata_bonuses': {
                'total_dmg': 30,
                'elemental_dmg': 50,
                'crit_rate': 10,
                'crit_dmg': 50
            },
            'rotation': [
                {'multiplier': 150, 'hits': 3},
                {'multiplier': 250, 'hits': 1}
            ]
        }
    ]
    
    comparison = calc.compare_builds(builds)
    
    print("\nBuild Comparison:")
    for build in comparison['comparison']:
        print(f"\n{build['name']}:")
        print(f"  DPS: {build['dps']:,}")
        print(f"  % of Best: {build['percent_of_best']}")
    
    print(f"\n🏆 Winner: {comparison['winner']['build_name']}")


def example_stat_optimization():
    """Example 4: Stat optimization"""
    print_header("Example 4: Stat Optimization")
    
    calc = DamageCalculator()
    
    current_stats = {
        'atk': 600,
        'crit_rate': 30,
        'crit_dmg': 80,
        'total_dmg': 40
    }
    
    result = calc.optimize_stats(current_stats, stat_points=50)
    
    print("\nCurrent Stats:")
    for stat, value in current_stats.items():
        print(f"  {stat.replace('_', ' ').title()}: {value}")
    
    print("\nOptimized Stats:")
    for stat, value in result['optimized'].items():
        print(f"  {stat.replace('_', ' ').title()}: {value}")
    
    print("\nImprovement:")
    print(f"  Before: {result['improvement']['before']:,} damage")
    print(f"  After: {result['improvement']['after']:,} damage")
    print(f"  Increase: +{result['improvement']['increase']:,}")
    print(f"  Percent: +{result['improvement']['percent_increase']}")


def example_character_analysis():
    """Example 5: Character data analysis"""
    print_header("Example 5: Character Data Analysis")
    
    data = load_character_data()
    characters = data['characters']
    
    print(f"\nTotal Characters: {len(characters)}")
    
    # Count by element
    elements = {}
    for char in characters:
        elem = char['element']
        elements[elem] = elements.get(elem, 0) + 1
    
    print("\nCharacters by Element:")
    for elem, count in sorted(elements.items()):
        print(f"  {elem}: {count}")
    
    # Count by tier
    tiers = {}
    for char in characters:
        tier = char['tierRating']
        tiers[tier] = tiers.get(tier, 0) + 1
    
    print("\nCharacters by Tier:")
    for tier, count in sorted(tiers.items(), reverse=True):
        print(f"  {tier}: {count}")
    
    # Highest ATK
    highest_atk = max(characters, key=lambda c: c['baseStats']['atk'])
    print(f"\nHighest ATK: {highest_atk['name']} ({highest_atk['baseStats']['atk']})")


def main():
    """Run all examples"""
    print("=" * 60)
    print("Honkai Impact 3rd Repository - Python Examples")
    print("=" * 60)
    
    try:
        example_basic_damage()
        example_dps_calculation()
        example_build_comparison()
        example_stat_optimization()
        example_character_analysis()
        
        print("\n" + "=" * 60)
        print("All examples completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
